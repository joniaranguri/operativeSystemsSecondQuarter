//este comentaro se usa de prueba
// este comentario se usa de prueba
no estoy comentando la linea
no estoy comentando la linea
no estoy comentando la linea
// este comentario se usa de prueba
hola // comento

en este archivo agrego mas lineas
// comentario
//comentario
/comentario